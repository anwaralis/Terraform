import azure.functions as func
import os
import csv
import logging
from azure.storage.blob import BlobServiceClient

app = func.FunctionApp()

# Load sensitive information from environment variables for security
CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING", "DefaultEndpointsProtocol=https;AccountName=costesdort;AccountKey=T3Og+8/Bj6iMoPaAeJP9t8NKwZ3i+WBZw5xsNVnT0j8693RMllFgYxMsqui+O4NxZ/XJgTLTmedS+AStyZZ/bA==;EndpointSuffix=core.windows.net")
CONTAINER_NAME = "cotssss"
OUTPUT_FILE_NAME = "costexport.csv"

@app.route(route="CostExportHttpTrigger", auth_level=func.AuthLevel.FUNCTION)
def CostExportHttpTrigger(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    if not CONNECTION_STRING:
        return func.HttpResponse(
            "Error: Connection string not found. Please set the AZURE_STORAGE_CONNECTION_STRING environment variable.",
            status_code=500
        )

    try:
        # Create a blob service client
        blob_service_client = BlobServiceClient.from_connection_string(CONNECTION_STRING)
        container_client = blob_service_client.get_container_client(CONTAINER_NAME)

        # Get list of blobs in the container
        blobs = container_client.list_blobs()
        csv_files = [blob for blob in blobs if blob.name.endswith('.csv') and blob.name != OUTPUT_FILE_NAME]

        # Sort files by last modified time (ascending) and exclude the newest one
        csv_files_sorted = sorted(csv_files, key=lambda x: x.last_modified)
        files_to_concat = csv_files_sorted[:-1]  # Exclude the newest one

        combined_data = []
        header_saved = False

        for blob in files_to_concat:
            blob_client = container_client.get_blob_client(blob.name)
            blob_data = blob_client.download_blob().readall().decode('utf-8')
            
            # Read CSV data
            csv_reader = csv.reader(blob_data.splitlines())
            header = next(csv_reader)
            if not header_saved:
                combined_data.append(header)
                header_saved = True

            for row in csv_reader:
                combined_data.append(row)
            
            # Rename blob by copying it to a new name with ".old" appended and then delete the original
            old_blob_name = blob.name + ".old"
            old_blob_client = container_client.get_blob_client(old_blob_name)
            old_blob_client.start_copy_from_url(blob_client.url)
            blob_client.delete_blob()

        # Write combined data to the output CSV file
        output_blob_client = container_client.get_blob_client(OUTPUT_FILE_NAME)
        with open("/tmp/temp.csv", "w", newline='') as temp_csv_file:
            csv_writer = csv.writer(temp_csv_file)
            csv_writer.writerows(combined_data)

        # Upload the combined CSV file to Azure Blob Storage
        with open("/tmp/temp.csv", "rb") as data:
            output_blob_client.upload_blob(data, overwrite=True)

        return func.HttpResponse(
            f"Successfully combined CSV files into {OUTPUT_FILE_NAME}",
            status_code=200
        )

    except Exception as e:
        return func.HttpResponse(
            f"An error occurred: {str(e)}",
            status_code=500
        )
